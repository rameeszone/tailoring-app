export const environment = {
	production: true,
	apiUrl: "https://your-production-api.com",
	appName: "Digital Tailoring System",
	version: "1.0.0"
};
