export const environment = {
	production: false,
	apiUrl: "http://localhost:3000",
	appName: "Digital Tailoring System",
	version: "1.0.0"
};
